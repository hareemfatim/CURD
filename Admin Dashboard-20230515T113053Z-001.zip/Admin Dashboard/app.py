from flask import Flask,render_template,request

from flask_mysqldb import MySQL
import os
from werkzeug.utils import secure_filename
app=Flask(__name__)

UPLOAD_FOLDER = 'static/img2'
ALLOWED_EXTENSIONS = set(['txt', 'pdf', 'png', 'jpg', 'jpeg', 'gif'])

app.config['MYSQL_HOST'] = 'localhost'
app.config['MYSQL_USER'] = 'root'
app.config['MYSQL_PASSWORD'] = ''
app.config['MYSQL_DB'] = 'oic'
app.config['UPLOAD_FOLDER'] = UPLOAD_FOLDER

mysql = MySQL(app)

@app.route('/')
def index():
    return render_template('index.html')



@app.route('/product',methods = ['GET','POST'])
def signup():

    if request.method == 'GET':
        return render_template('create.html')
    elif request.method == 'POST':
        Product_Name = request.form['Product_Name']
        Product_Price = request.form['Product_Price']
        Product_Qty = request.form['Product_Qty']
        Product_Des = request.form['Product_Des']
        Product_Image = request.files['Product_Image']
        p_img=secure_filename(Product_Image.filename)
        Product_Image.save(os.path.join(app.config['UPLOAD_FOLDER'],p_img)) 
        cursor = mysql.connection.cursor()
        cursor.execute('''INSERT INTO `product` (`Product_Name`, `Product_Price`, `Product_Qty`, `Product_Des`,`Product_Image`) VALUES (%s,%s,%s,%s,%s)''',(Product_Name,Product_Price,Product_Qty, Product_Des,p_img))
        mysql.connection.commit()
        cursor.close()
        return 'Dear '+ Product_Name + ", you're product successfully inserted"
    





@app.route('/table')
def table():
   
    cursor = mysql.connection.cursor()
    no_of_rows = cursor.execute("SELECT * FROM product")
    if no_of_rows > 0:
        users = cursor.fetchall()
        return render_template('table.html', users=users)
    else:
        return "No Records Found"



@app.route("/edit/<id>",methods=['GET','POST'])
def get_user(id):
    cursor = mysql.connection.cursor()
    cursor.execute('SELECT * FROM product WHERE Product_id = %s',(id))
    data = cursor.fetchall()
    cursor.close()
    print(data[0])
    return render_template("edit.html",users=data[0])

@app.route("/update/<id>", methods=['POST'])
def Update_user(id):
    if request.method == 'POST':
        Product_Name = request.form['Product_Name']
        Product_Price = request.form['Product_Price']
        Product_Qty = request.form['Product_Qty']
        Product_Des = request.form['Product_Des']
        Product_Image = request.files['Product_Image']
        p_img=secure_filename(Product_Image.filename)
        Product_Image.save(os.path.join(app.config['UPLOAD_FOLDER'],p_img)) 
        cursor = mysql.connection.cursor()
        cursor.execute('''UPDATE product SET Product_Name=%s, Product_Price=%s, Product_Qty=%s,Product_Image=%s, Product_Des=%s WHERE Product_Id=%s''',(Product_Name,Product_Price,Product_Qty, p_img,Product_Des,id))
        mysql.connection.commit()
        cursor.close()
        return 'Dear '+ Product_Name + ", you're product successfully inserted"

@app.route("/delete/<id>", methods=['GET','POST'])
def delete_user(id):
    cursor = mysql.connection.cursor()
    cursor.execute('''DELETE  FROM product WHERE Product_id = %s''',(id))
    mysql.connection.commit()
    return"Recorde has been deleted successfully!"

if __name__ == "__main__":
    app.run(debug=True)
    
